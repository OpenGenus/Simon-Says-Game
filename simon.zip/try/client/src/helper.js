// export const BASE_URL='https://simongame-qp5t.onrender.com';

export const BASE_URL='http://localhost:8080';
